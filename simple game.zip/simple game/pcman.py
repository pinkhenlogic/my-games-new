import pygame
import sys
import random

pygame.init()

WIDTH, HEIGHT = 640, 480
TILE_SIZE = 32

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pac-Man with Smart Ghost")

clock = pygame.time.Clock()

BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

def generate_maze(rows, cols):
    maze = []
    for y in range(rows):
        row = ""
        for x in range(cols):
            if y == 0 or y == rows - 1 or x == 0 or x == cols - 1:
                row += "W"
            elif random.random() < 0.1:
                row += "W"
            elif random.random() < 0.6:
                row += "D"
            else:
                row += " "
        maze.append(row)
    maze[1] = maze[1][:1] + " " + maze[1][2:]
    return maze

mazes = [generate_maze(13, 20) for _ in range(50)]

def load_maze(index):
    global maze, pacman_x, pacman_y, ghost_x, ghost_y, score, total_dots
    maze = [list(row) for row in mazes[index]]
    pacman_x, pacman_y = 1, 1
    ghost_x, ghost_y = len(maze[0]) - 2, len(maze) - 2
    score = 0
    total_dots = sum(row.count('D') for row in maze)

level = 0
load_maze(level)

running = True
win_timer = 0
font = pygame.font.SysFont(None, 50)
ghost_move_timer = 0
ghost_speed = 500  # ghost moves every 500 milliseconds

while running:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Player movement
    keys = pygame.key.get_pressed()
    dx, dy = 0, 0
    if keys[pygame.K_LEFT]: dx = -1
    if keys[pygame.K_RIGHT]: dx = 1
    if keys[pygame.K_UP]: dy = -1
    if keys[pygame.K_DOWN]: dy = 1

    new_x = pacman_x + dx
    new_y = pacman_y + dy
    if 0 <= new_x < len(maze[0]) and 0 <= new_y < len(maze):
        if maze[new_y][new_x] != 'W':
            pacman_x, pacman_y = new_x, new_y
            if maze[pacman_y][pacman_x] == 'D':
                maze[pacman_y][pacman_x] = ' '
                score += 1

    # Ghost movement (chases Pac-Man slowly)
    now = pygame.time.get_ticks()
    if now - ghost_move_timer > ghost_speed:
        ghost_move_timer = now

        directions = [(0, -1), (1, 0), (0, 1), (-1, 0)]  # up, right, down, left
        best_move = (0, 0)
        min_distance = float('inf')

        for dx, dy in directions:
            gx = ghost_x + dx
            gy = ghost_y + dy
            if 0 <= gx < len(maze[0]) and 0 <= gy < len(maze):
                if maze[gy][gx] != 'W':
                    distance = abs(gx - pacman_x) + abs(gy - pacman_y)
                    if distance < min_distance:
                        min_distance = distance
                        best_move = (dx, dy)

        ghost_x += best_move[0]
        ghost_y += best_move[1]

    # Draw maze
    for y in range(len(maze)):
        for x in range(len(maze[0])):
            rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
            tile = maze[y][x]
            if tile == 'W':
                pygame.draw.rect(screen, BLUE, rect)
            elif tile == 'D':
                pygame.draw.circle(screen, WHITE, rect.center, 5)

    # Draw Pac-Man
    pac_rect = pygame.Rect(pacman_x * TILE_SIZE, pacman_y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
    pygame.draw.circle(screen, YELLOW, pac_rect.center, TILE_SIZE // 2 - 2)

    # Draw Ghost
    ghost_rect = pygame.Rect(ghost_x * TILE_SIZE, ghost_y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
    pygame.draw.circle(screen, RED, ghost_rect.center, TILE_SIZE // 2 - 2)

    # Check collision with ghost
    if pacman_x == ghost_x and pacman_y == ghost_y:
        text = font.render("Caught by the Ghost! Restarting...", True, RED)
        screen.blit(text, (40, HEIGHT // 2))
        pygame.display.flip()
        pygame.time.wait(2000)
        level = 0
        load_maze(level)
        continue

    # Win condition
    if score == total_dots:
        if win_timer == 0:
            win_timer = pygame.time.get_ticks()
        if pygame.time.get_ticks() - win_timer < 2000:
            text = font.render(f"LEVEL {level + 1} COMPLETE!", True, YELLOW)
            screen.blit(text, (WIDTH // 2 - 180, HEIGHT // 2 - 30))
        else:
            level += 1
            if level < len(mazes):
                load_maze(level)
                win_timer = 0
            else:
                text = font.render("YOU BEAT ALL 50 LEVELS!", True, YELLOW)
                screen.fill(BLACK)
                screen.blit(text, (WIDTH // 2 - 200, HEIGHT // 2 - 30))
                pygame.display.flip()
                pygame.time.wait(3000)
                running = False

    pygame.display.flip()
    clock.tick(10)

pygame.quit()
sys.exit()
0