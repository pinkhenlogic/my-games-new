import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up the display
WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bouncing Square")

# Define square properties
square_size = 50
x, y = WIDTH // 2, HEIGHT // 2
x_speed, y_speed = 4, 3
color = (0, 255, 0)

clock = pygame.time.Clock()
running = True
while running:
    screen.fill((0, 0, 0))  # Clear screen

    # Handle quitting
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update position
    x += x_speed
    y += y_speed

    # Bounce off walls
    if x <= 0 or x + square_size >= WIDTH:
        x_speed = -x_speed
    if y <= 0 or y + square_size >= HEIGHT:
        y_speed = -y_speed

    # Draw the square
    pygame.draw.rect(screen, color, (x, y, square_size, square_size))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
