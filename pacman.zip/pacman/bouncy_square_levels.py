import pygame
import sys
import random

pygame.init()

# Screen settings
WIDTH, HEIGHT = 700, 450
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Escape Square Game")

# Font
font = pygame.font.SysFont(None, 32)

# Colors
colors = [(255, 0, 0), (0, 255, 0), (0, 100, 255), (255, 255, 0)]
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BUTTON_COLOR = (50, 150, 50)
BUTTON_HOVER = (70, 200, 70)
TAB_COLOR = (80, 80, 80)
TAB_ACTIVE = (180, 180, 180)

square_size = 40
clock = pygame.time.Clock()

# Scores
scores = {1: 0, 2: 0, 3: 0, 4: 0}

# Difficulty settings
difficulty_levels = {
    "Easy": 2,
    "Medium": 4,
    "Hard": 6
}
current_difficulty = "Medium"

# Game state
def create_squares(speed):
    squares = []
    for i in range(4):
        x = random.randint(0, WIDTH - square_size - 100)
        y = random.randint(0, HEIGHT - square_size)
        x_speed = random.choice([-speed, speed])
        y_speed = random.choice([-speed + 1, speed - 1])
        color = colors[i]
        squares.append({
            "x": x,
            "y": y,
            "x_speed": x_speed,
            "y_speed": y_speed,
            "color": color,
            "alive": True,
            "id": i + 1
        })
    return squares

squares = create_squares(difficulty_levels[current_difficulty])
winner_declared = False
winner_text = ""
winner_timer = 0  # Count frames to wait before restarting

def draw_button(text, x, y, w, h, action=None, is_tab=False, active=False):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    rect = pygame.Rect(x, y, w, h)
    color = TAB_ACTIVE if active else (TAB_COLOR if is_tab else BUTTON_COLOR)
    if rect.collidepoint(mouse):
        color = BUTTON_HOVER
        if click[0] == 1 and action:
            pygame.time.wait(200)
            action()
    pygame.draw.rect(screen, color, rect)
    label = font.render(text, True, BLACK)
    label_rect = label.get_rect(center=rect.center)
    screen.blit(label, label_rect)
    return rect

def restart_game():
    global squares, winner_declared, winner_text, winner_timer
    squares = create_squares(difficulty_levels[current_difficulty])
    winner_declared = False
    winner_text = ""
    winner_timer = 0

def set_difficulty(level):
    global current_difficulty
    current_difficulty = level
    restart_game()

running = True
while running:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Draw difficulty tabs
    draw_button("Easy", 10, 10, 80, 35, lambda: set_difficulty("Easy"),
                is_tab=True, active=current_difficulty == "Easy")
    draw_button("Medium", 100, 10, 100, 35, lambda: set_difficulty("Medium"),
                is_tab=True, active=current_difficulty == "Medium")
    draw_button("Hard", 210, 10, 80, 35, lambda: set_difficulty("Hard"),
                is_tab=True, active=current_difficulty == "Hard")

    # Restart button
    draw_button("Restart", WIDTH - 120, 10, 100, 35, restart_game)

    if not winner_declared:
        alive_squares = [s for s in squares if s["alive"]]

        for square in alive_squares:
            square["x"] += square["x_speed"]
            square["y"] += square["y_speed"]

            if square["x"] <= 0:
                square["x_speed"] *= -1
            if square["y"] <= 0 or square["y"] + square_size >= HEIGHT:
                square["y_speed"] *= -1
            if square["x"] > WIDTH:
                square["alive"] = False
                continue

            pygame.draw.rect(screen, square["color"],
                             (square["x"], square["y"], square_size, square_size))
            label = font.render(str(square["id"]), True, BLACK)
            label_rect = label.get_rect(center=(square["x"] + square_size // 2,
                                                square["y"] + square_size // 2))
            screen.blit(label, label_rect)

        if len(alive_squares) == 1:
            winner = alive_squares[0]
            scores[winner["id"]] += 1
            winner_text = f"Square {winner['id']} Wins!"
            winner_declared = True
            winner_timer = 180  # Show message for 3 seconds at 60 FPS

        elif len(alive_squares) == 0:
            winner_text = "No winner! Everyone escaped!"
            winner_declared = True
            winner_timer = 180

    else:
        # Display winner message and count down
        text = font.render(winner_text, True, WHITE)
        screen.blit(text, (WIDTH // 2 - 150, HEIGHT // 2))
        winner_timer -= 1
        if winner_timer <= 0:
            restart_game()

    # Draw scores
    score_text = "  ".join([f"{i}: {scores[i]}" for i in range(1, 5)])
    score_surface = font.render(f"Scores - {score_text}", True, WHITE)
    screen.blit(score_surface, (10, HEIGHT - 40))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
