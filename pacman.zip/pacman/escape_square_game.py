import pygame
import sys
import random

pygame.init()

# Screen settings
WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Escape Square Game")

# Font
font = pygame.font.SysFont(None, 36)

# Colors
colors = [(255, 0, 0), (0, 255, 0), (0, 100, 255), (255, 255, 0)]
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BUTTON_COLOR = (50, 150, 50)
BUTTON_HOVER = (70, 200, 70)

square_size = 40
clock = pygame.time.Clock()

# Scoreboard
scores = {1: 0, 2: 0, 3: 0, 4: 0}

# Game state
def create_squares():
    squares = []
    for i in range(4):
        x = random.randint(0, WIDTH - square_size - 100)
        y = random.randint(0, HEIGHT - square_size)
        x_speed = random.choice([-4, 4])
        y_speed = random.choice([-3, 3])
        color = colors[i]
        squares.append({
            "x": x,
            "y": y,
            "x_speed": x_speed,
            "y_speed": y_speed,
            "color": color,
            "alive": True,
            "id": i + 1
        })
    return squares

squares = create_squares()
winner_declared = False
running = True

def draw_restart_button():
    mouse = pygame.mouse.get_pos()
    button_rect = pygame.Rect(WIDTH // 2 - 60, HEIGHT // 2 + 50, 120, 40)
    color = BUTTON_HOVER if button_rect.collidepoint(mouse) else BUTTON_COLOR
    pygame.draw.rect(screen, color, button_rect)
    text = font.render("RESTART", True, BLACK)
    text_rect = text.get_rect(center=button_rect.center)
    screen.blit(text, text_rect)
    return button_rect

while running:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Handle restart click
        if winner_declared and event.type == pygame.MOUSEBUTTONDOWN:
            if draw_restart_button().collidepoint(event.pos):
                squares = create_squares()
                winner_declared = False

    alive_squares = [s for s in squares if s["alive"]]

    for square in alive_squares:
        square["x"] += square["x_speed"]
        square["y"] += square["y_speed"]

        if square["x"] <= 0:
            square["x_speed"] *= -1
        if square["y"] <= 0 or square["y"] + square_size >= HEIGHT:
            square["y_speed"] *= -1
        if square["x"] > WIDTH:
            square["alive"] = False
            continue

        pygame.draw.rect(screen, square["color"],
                         (square["x"], square["y"], square_size, square_size))
        label = font.render(str(square["id"]), True, BLACK)
        label_rect = label.get_rect(center=(square["x"] + square_size // 2,
                                            square["y"] + square_size // 2))
        screen.blit(label, label_rect)

    # Show winner
    if len(alive_squares) == 1 and not winner_declared:
        winner = alive_squares[0]
        scores[winner["id"]] += 1
        text = font.render(f"Square {winner['id']} Wins!", True, WHITE)
        screen.blit(text, (WIDTH // 2 - 100, HEIGHT // 2))
        draw_restart_button()
        winner_declared = True

    elif len(alive_squares) == 0 and not winner_declared:
        text = font.render("No winner! Everyone escaped!", True, WHITE)
        screen.blit(text, (WIDTH // 2 - 150, HEIGHT // 2))
        draw_restart_button()
        winner_declared = True

    # Draw scores at top
    score_text = "  ".join([f"{i}: {scores[i]}" for i in range(1, 5)])
    score_surface = font.render(f"Scores - {score_text}", True, WHITE)
    screen.blit(score_surface, (10, 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
