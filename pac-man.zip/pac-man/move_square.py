import pygame
import sys
import time

# Initialize Pygame
pygame.init()

# Set up screen
screen = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Enemy Chase Game")

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)

# Set up font for score display
font = pygame.font.SysFont(None, 36)

def play_game():
    # Player setup
    player_x = 250
    player_y = 250
    player_size = 40
    player_speed = 5

    # Enemy setup
    enemy_x = 50
    enemy_y = 50
    enemy_size = 40
    enemy_speed = 2

    clock = pygame.time.Clock()
    running = True

    # Start the score timer
    start_time = time.time()

    while running:
        clock.tick(60)
        screen.fill(WHITE)

        # Quit event
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Handle key presses and screen boundaries
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < 500 - player_size:
            player_x += player_speed
        if keys[pygame.K_UP] and player_y > 0:
            player_y -= player_speed
        if keys[pygame.K_DOWN] and player_y < 500 - player_size:
            player_y += player_speed

        # Enemy follows player
        if enemy_x < player_x:
            enemy_x += enemy_speed
        elif enemy_x > player_x:
            enemy_x -= enemy_speed

        if enemy_y < player_y:
            enemy_y += enemy_speed
        elif enemy_y > player_y:
            enemy_y -= enemy_speed

        # Draw player and enemy
        player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
        enemy_rect = pygame.Rect(enemy_x, enemy_y, enemy_size, enemy_size)
        pygame.draw.rect(screen, BLUE, player_rect)
        pygame.draw.rect(screen, RED, enemy_rect)

        # Score calculation
        current_time = time.time()
        score = int(current_time - start_time)
        score_text = font.render(f"Score: {score}", True, BLACK)
        screen.blit(score_text, (10, 10))  # Draw score at top-left

        # Collision check
        if player_rect.colliderect(enemy_rect):
            print(f"💥 You survived for {score} seconds! Restarting...")
            pygame.time.delay(1500)  # Pause 1.5 seconds
            play_game()  # Restart
            return

        pygame.display.update()

# Start game
play_game()
