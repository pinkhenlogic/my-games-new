import pygame
import random
import sys
import os

# Initialize
pygame.init()
pygame.mixer.init()

# Screen setup
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bouncy Squares Escape Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
COLORS = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]

# Fonts
font = pygame.font.SysFont(None, 48)
small_font = pygame.font.SysFont(None, 30)

# Sounds
try:
    win_sound = pygame.mixer.Sound("win.wav")
except:
    win_sound = None

# Load chicken image
try:
    chicken_img = pygame.image.load("chicken.png").convert_alpha()
    chicken_img = pygame.transform.scale(chicken_img, (120, 120))
except:
    chicken_img = None

# Game variables
SQUARE_SIZE = 40
SPEED = 5
LEVELS = {"Easy": 3, "Medium": 6, "Hard": 10}
difficulty = "Medium"

# UI buttons
restart_button = pygame.Rect(WIDTH - 150, 10, 130, 40)
level_buttons = {
    "Easy": pygame.Rect(10, 10, 80, 40),
    "Medium": pygame.Rect(100, 10, 100, 40),
    "Hard": pygame.Rect(210, 10, 80, 40)
}

# Square class
class Square:
    def __init__(self, x, y, dx, dy, color, label):
        self.rect = pygame.Rect(x, y, SQUARE_SIZE, SQUARE_SIZE)
        self.dx = dx
        self.dy = dy
        self.color = color
        self.label = label

    def move(self):
        self.rect.x += self.dx
        self.rect.y += self.dy

        # Bounce off top, bottom, right
        if self.rect.top <= 0 or self.rect.bottom >= HEIGHT:
            self.dy *= -1
        if self.rect.right >= WIDTH:
            self.dx *= -1
        # Left side is open!

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)
        label_text = small_font.render(str(self.label), True, BLACK)
        surface.blit(label_text, (self.rect.x + 10, self.rect.y + 5))

def create_squares(speed):
    squares = []
    for i in range(4):
        x = random.randint(WIDTH // 2, WIDTH - SQUARE_SIZE)
        y = random.randint(0, HEIGHT - SQUARE_SIZE)
        dx = random.choice([-speed, speed])
        dy = random.choice([-speed, speed])
        squares.append(Square(x, y, dx, dy, COLORS[i], i + 1))
    return squares

squares = create_squares(LEVELS[difficulty])
winner_declared = False
winner = None
winner_timer = 0

# Restart game
def restart_game():
    global squares, winner_declared, winner, winner_timer
    squares = create_squares(LEVELS[difficulty])
    winner_declared = False
    winner = None
    winner_timer = 0

# Main loop
clock = pygame.time.Clock()
running = True

while running:
    screen.fill(BLACK)

    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if restart_button.collidepoint(event.pos):
                restart_game()
            for level, btn in level_buttons.items():
                if btn.collidepoint(event.pos):
                    difficulty = level
                    restart_game()

    # Update squares
    if not winner_declared:
        for square in squares:
            square.move()
            if square.rect.left < 0:
                winner = square.label
                winner_declared = True
                winner_timer = 180  # 3 seconds at 60 FPS
                if win_sound:
                    win_sound.play()
    else:
        winner_text = f"Square {winner} Wins!"
        text = font.render(winner_text, True, WHITE)
        screen.blit(text, (WIDTH // 2 - 150, HEIGHT // 2))

        # Show chicken image
        if chicken_img:
            chicken_rect = chicken_img.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 80))
            screen.blit(chicken_img, chicken_rect)

        winner_timer -= 1
        if winner_timer <= 0:
            restart_game()

    # Draw squares
    for square in squares:
        square.draw(screen)

    # Draw walls (top, right, bottom only)
    pygame.draw.rect(screen, WHITE, pygame.Rect(0, 0, WIDTH, 5))  # Top
    pygame.draw.rect(screen, WHITE, pygame.Rect(WIDTH - 5, 0, 5, HEIGHT))  # Right
    pygame.draw.rect(screen, WHITE, pygame.Rect(0, HEIGHT - 5, WIDTH, 5))  # Bottom

    # Draw buttons
    pygame.draw.rect(screen, WHITE, restart_button, 2)
    screen.blit(small_font.render("Restart", True, WHITE), (restart_button.x + 25, restart_button.y + 10))

    for level, btn in level_buttons.items():
        pygame.draw.rect(screen, WHITE, btn, 2)
        color = WHITE if difficulty != level else COLORS[2]
        label = small_font.render(level, True, color)
        screen.blit(label, (btn.x + 10, btn.y + 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
